package com.acm.proyectoacm.services.impl;

import com.acm.proyectoacm.dto.CartDTO;
import com.acm.proyectoacm.dto.CartProductDTO;
import com.acm.proyectoacm.dto.ProductDTO;
import com.acm.proyectoacm.dto.UserDTO;
import com.acm.proyectoacm.services.IUserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements IUserService {

    private final RestTemplate restTemplate;


    @Override
    public List<UserDTO> getAllUsers() {
        UserDTO[] users = restTemplate.getForObject("/users", UserDTO[].class);
        assert users != null;
        return List.of(users);
    }

    @Override
    public UserDTO getUserByid(int id) {
        return restTemplate.getForObject("/users/{id}", UserDTO.class, id);
    }

    @Override
    public List<CartDTO> getCartsByUserId(int userId) {
        CartDTO[] carts = restTemplate.getForObject("/carts/user/" + userId, CartDTO[].class);
        assert carts != null;
        return Arrays.asList(carts);
    }

    public ProductDTO getProductById(int id) {
        return restTemplate.getForObject("/products/{id}", ProductDTO.class, id);
    }

    public List<ProductDTO> getAllProducts() {
        ProductDTO[] products = restTemplate.getForObject("/products", ProductDTO[].class);
        assert products != null;
        return Arrays.asList(products);
    }




}

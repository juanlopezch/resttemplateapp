package com.acm.proyectoacm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoAcmApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProyectoAcmApplication.class, args);
    }

}

package com.acm.proyectoacm.dto;

import lombok.Data;

@Data
public class CartProductDTO {
    private int productId;
    private int quantity;
}

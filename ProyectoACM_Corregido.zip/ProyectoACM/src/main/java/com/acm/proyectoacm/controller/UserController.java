package com.acm.proyectoacm.controller;
import com.acm.proyectoacm.dto.UserDTO;
import jakarta.validation.Valid;
import com.acm.proyectoacm.services.IUserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
public class UserController {

    private final IUserService userService;

    @GetMapping
    public ResponseEntity<?> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable int id) {
        return ResponseEntity.ok(userService.getUserByid(id));

    }

    @GetMapping("/{id}/carts")
    public ResponseEntity<?> getCartsByUserId(@PathVariable int id) {
        return ResponseEntity.ok(userService.getCartsByUserId(id));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody @Valid UserDTO userDTO) {
        List<UserDTO> users = userService.getAllUsers();

        UserDTO matchedUser = users.stream()
                .filter(u -> u.getUsuario().equals(userDTO.getUsuario()) && u.getClave().equals(userDTO.getClave()))
                .findFirst()
                .orElse(null);

        if (matchedUser != null) {
            return ResponseEntity.ok(matchedUser);
        } else {
            return ResponseEntity.status(401).body("Credenciales inválidas");
        }
    }
    @GetMapping("/products")
    public ResponseEntity<?> getAllProducts() {
        return ResponseEntity.ok(userService.getAllProducts());
    }


}



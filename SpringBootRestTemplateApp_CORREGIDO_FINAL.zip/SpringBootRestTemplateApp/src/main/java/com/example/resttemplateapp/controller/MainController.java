package com.example.resttemplateapp.controller;

import com.example.resttemplateapp.dto.ProductDto;
import com.example.resttemplateapp.service.ApiService;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.util.List;

@Controller
public class MainController {

    @Autowired
    private ApiService apiService;

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("loginForm", new LoginForm());
        return "index";
    }

    @PostMapping("/login")
    public String login(@Valid @ModelAttribute("loginForm") LoginForm loginForm, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return "index";
        }
        List<ProductDto> products = apiService.getProductsByUser(loginForm.getUsername(), loginForm.getPassword());
        model.addAttribute("products", products);
        return "products";
    }

    @GetMapping("/carts")
    public String getCarts(@RequestParam("userId") int userId, Model model) {
        List<com.example.resttemplateapp.dto.CartDto> carts = apiService.getCartsByUserId(userId);
        model.addAttribute("carts", carts);
        return "carts";
    }

    public static class LoginForm {
        @NotBlank(message = "Username is required")
        private String username;

        @NotBlank(message = "Password is required")
        private String password;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }
}
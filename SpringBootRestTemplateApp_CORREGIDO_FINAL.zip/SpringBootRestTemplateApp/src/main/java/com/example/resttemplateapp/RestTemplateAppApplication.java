
package com.example.resttemplateapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestTemplateAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(RestTemplateAppApplication.class, args);
    }
}

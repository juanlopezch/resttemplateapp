
package com.example.resttemplateapp.dto;

import lombok.Data;

import java.util.List;

@Data
public class CartDto {
    private int id;
    private int userId;
    private String date;
    private List<ProductInCart> products;

    @Data
    public static class ProductInCart {
        private int productId;
        private int quantity;
    }
}

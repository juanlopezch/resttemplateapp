package com.example.resttemplateapp.service;

import com.example.resttemplateapp.dto.CartDto;
import com.example.resttemplateapp.dto.ProductDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Service
public class ApiService {

    private final RestTemplate restTemplate;

    @Autowired
    public ApiService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<CartDto> getCartsByUserId(int userId) {
        String url = "https://fakestoreapi.com/carts/user/" + userId;
        CartDto[] response = restTemplate.getForObject(url, CartDto[].class);
        return Arrays.asList(response);
    }

    public List<ProductDto> getAllProducts() {
        String url = "https://fakestoreapi.com/products";
        ProductDto[] response = restTemplate.getForObject(url, ProductDto[].class);
        return Arrays.asList(response);
    }

    public List<ProductDto> getProductsByUser(String username, String password) {
        // Aquí deberías validar contra usuarios existentes (simplificado para taller)
        return getAllProducts();
    }
}